/* 
PEC 2 Fundamentos de Inteligencia Artificial: SBR 

Simulador Absurdo de Conversaciones Incomodas: Edición Boda

Manuel F.
*/

/*
  auxiliar.pl Archivo encargado de los predicados auxiliares.
*/

/*
  Funciones auxiliares para trabajar con listas
*/
  
% Añadir un elemento

addElement(X, L, [X|L]).

% Borra primera aparición elemento

eliminaElemento(X,[X|R],R) :- !.
eliminaElemento(X,[H|R],[H|R2]) :- eliminaElemento(X,R,R2).

% Comprueba si  un elemento no esta en una lista.

noEstaElemento(X,[Y]) :- X \= Y, !.
noEstaElemento(X, [Y|R]) :- X \= Y, noEstaElemento(X,R), !.

% Obtiene elemento al azar de una lista.

elementoAzar(Lista, R) :- length(Lista, L), Aleatorio is random(L), nth0(Aleatorio, Lista, R).

% Concatena dos listas

concatena([], L, L).
concatena([X|R1],L2,[X|S]) :- concatena(R1,L2,S).

% Baraja el contenido de una lista.

baraja([],[]) :- !.
baraja(L,[X|R]) :- elementoAzar(L,X), eliminaElemento(X,L,NL), baraja(NL,R). 

/*
 Otros auxiliares
*/
 
% Resta dos números.

res(A,B,C) :- C is A - B.

% Dado un numero devuelve la mitad de la mitad y el numero menos el número anterior.

divideNum(Num, P, S) :- A is Num // 2, P is A // 2, DP is P * 2, S is Num - DP.

/*
  Auxiliares para trabajar con listas en la conversación.
*/
  
% Obtiene entradilla que da paso a la frase de un invitado según sus características..

% hipster
obtieneEntrada(N, F) :- N = 'hipsterfemeninovermut', hipsterfemeninovermut(F),!.  
obtieneEntrada(N, F) :- N = 'hipsterfemeninocena', hipsterfemeninocena(F),!.  
obtieneEntrada(N, F) :- N = 'hipsterfemeninocopas', hipsterfemeninocopas(F),!.  

obtieneEntrada(N, F) :- N = 'hipstermasculinovermut', hipstermasculinovermut(F),!.  
obtieneEntrada(N, F) :- N = 'hipstermasculinocena', hipstermasculinocena(F),!.  
obtieneEntrada(N, F) :- N = 'hipstermasculinocopas', hipstermasculinocopas(F),!.  

% hippie
obtieneEntrada(N, F) :- N = 'hippiefemeninovermut', hippiefemeninovermut(F),!.  
obtieneEntrada(N, F) :- N = 'hippiefemeninocena', hippiefemeninocena(F),!.  
obtieneEntrada(N, F) :- N = 'hippiefemeninocopas', hippiefemeninocopas(F),!.  

obtieneEntrada(N, F) :- N = 'hippiemasculinovermut', hippiemasculinovermut(F),!.  
obtieneEntrada(N, F) :- N = 'hippiemasculinocena', hippiemasculinocena(F),!.  
obtieneEntrada(N, F) :- N = 'hippiemasculinocopas', hippiemasculinocopas(F),!.  

% karmawhore
obtieneEntrada(N, F) :- N = 'karmawhorefemeninovermut', karmawhorefemeninovermut(F),!.  
obtieneEntrada(N, F) :- N = 'karmawhorefemeninocena', karmawhorefemeninocena(F),!.  
obtieneEntrada(N, F) :- N = 'karmawhorefemeninocopas', karmawhorefemeninocopas(F),!.  

obtieneEntrada(N, F) :- N = 'karmawhoremasculinovermut', karmawhoremasculinovermut(F),!.  
obtieneEntrada(N, F) :- N = 'karmawhoremasculinocena', karmawhoremasculinocena(F),!.  
obtieneEntrada(N, F) :- N = 'karmawhoremasculinocopas', karmawhoremasculinocopas(F),!.  

% Obtiene las listas que contienen las frases para un invitado según sus características.

% hippie

% vermut
% hippie  pobre
obtieneLista(N,L) :- N = 'hippiepobrevermuttiempo', hippiepobrevermuttiempo(L),!.
obtieneLista(N,L) :- N = 'hippiepobrevermutnovios', hippiepobrevermutnovios(L),!.
obtieneLista(N,L) :- N = 'hippiepobrevermutrestaurante', hippiepobrevermutrestaurante(L),!.

% hippie  pudiente
obtieneLista(N,L) :- N = 'hippiepudientevermuttiempo', hippiepudientevermuttiempo(L),!.
obtieneLista(N,L) :- N = 'hippiepudientevermutnovios', hippiepudientevermutnovios(L),!.
obtieneLista(N,L) :- N = 'hippiepudientevermutrestaurante', hippiepudientevermutrestaurante(L),!.

% hipster

% vermut
% hipster  pobre
obtieneLista(N,L) :- N = 'hipsterpobrevermuttiempo', hipsterpobrevermuttiempo(L),!.
obtieneLista(N,L) :- N = 'hipsterpobrevermutnovios', hipsterpobrevermutnovios(L),!.
obtieneLista(N,L) :- N = 'hipsterpobrevermutrestaurante', hipsterpobrevermutrestaurante(L),!.

% hipster  pudiente
obtieneLista(N,L) :- N = 'hipsterpudientevermuttiempo', hipsterpudientevermuttiempo(L),!.
obtieneLista(N,L) :- N = 'hipsterpudientevermutnovios', hipsterpudientevermutnovios(L),!.
obtieneLista(N,L) :- N = 'hipsterpudientevermutrestaurante', hipsterpudientevermutrestaurante(L),!.

% karmawhore

% vermut
% karmawhore  pobre
obtieneLista(N,L) :- N = 'karmawhorepobrevermuttiempo', karmawhorepobrevermuttiempo(L),!.
obtieneLista(N,L) :- N = 'karmawhorepobrevermutnovios', karmawhorepobrevermutnovios(L),!.
obtieneLista(N,L) :- N = 'karmawhorepobrevermutrestaurante', karmawhorepobrevermutrestaurante(L),!.

% karmawhore  pudiente
obtieneLista(N,L) :- N = 'karmawhorepudientevermuttiempo', karmawhorepudientevermuttiempo(L),!.
obtieneLista(N,L) :- N = 'karmawhorepudientevermutnovios', karmawhorepudientevermutnovios(L),!.
obtieneLista(N,L) :- N = 'karmawhorepudientevermutrestaurante', karmawhorepudientevermutrestaurante(L),!.

% hippie

% cena
% hippie  pobre
obtieneLista(N,L) :- N = 'hippiepobrecenapolitica', hippiepobrecenapolitica(L),!.
obtieneLista(N,L) :- N = 'hippiepobrecenatelevision', hippiepobrecenatelevision(L),!.
obtieneLista(N,L) :- N = 'hippiepobrecenacomida', hippiepobrecenacomida(L),!.

% hippie  pudiente
obtieneLista(N,L) :- N = 'hippiepudientecenapolitica', hippiepudientecenapolitica(L),!.
obtieneLista(N,L) :- N = 'hippiepudientecenatelevision', hippiepudientecenatelevision(L),!.
obtieneLista(N,L) :- N = 'hippiepudientecenacomida', hippiepudientecenacomida(L),!.

% hipster

% cena
% hipster  pobre
obtieneLista(N,L) :- N = 'hipsterpobrecenapolitica', hipsterpobrecenapolitica(L),!.
obtieneLista(N,L) :- N = 'hipsterpobrecenatelevision', hipsterpobrecenatelevision(L),!.
obtieneLista(N,L) :- N = 'hipsterpobrecenacomida', hipsterpobrecenacomida(L),!.

% hipster  pudiente
obtieneLista(N,L) :- N = 'hipsterpudientecenapolitica', hipsterpudientecenapolitica(L),!.
obtieneLista(N,L) :- N = 'hipsterpudientecenatelevision', hipsterpudientecenatelevision(L),!.
obtieneLista(N,L) :- N = 'hipsterpudientecenacomida', hipsterpudientecenacomida(L),!.

% karmawhore

% cena
% karmawhore  pobre
obtieneLista(N,L) :- N = 'karmawhorepobrecenapolitica', karmawhorepobrecenapolitica(L),!.
obtieneLista(N,L) :- N = 'karmawhorepobrecenatelevision', karmawhorepobrecenatelevision(L),!.
obtieneLista(N,L) :- N = 'karmawhorepobrecenacomida', karmawhorepobrecenacomida(L),!.

% karmawhore  pudiente
obtieneLista(N,L) :- N = 'karmawhorepudientecenapolitica', karmawhorepudientecenapolitica(L),!.
obtieneLista(N,L) :- N = 'karmawhorepudientecenatelevision', karmawhorepudientecenatelevision(L),!.
obtieneLista(N,L) :- N = 'karmawhorepudientecenacomida', karmawhorepudientecenacomida(L),!.

% hippie

% copas
% hippie  pobre
obtieneLista(N,L) :- N = 'hippiepobrecopaspolitica', hippiepobrecopaspolitica(L),!.
obtieneLista(N,L) :- N = 'hippiepobrecopasdeportes', hippiepobrecopasdeportes(L),!.
obtieneLista(N,L) :- N = 'hippiepobrecopasmusica', hippiepobrecopasmusica(L),!.

% hippie  pudiente
obtieneLista(N,L) :- N = 'hippiepudientecopaspolitica', hippiepudientecopaspolitica(L),!.
obtieneLista(N,L) :- N = 'hippiepudientecopasdeportes', hippiepudientecopasdeportes(L),!.
obtieneLista(N,L) :- N = 'hippiepudientecopasmusica', hippiepudientecopasmusica(L),!.

% hipster

% copas
% hipster  pobre
obtieneLista(N,L) :- N = 'hipsterpobrecopaspolitica', hipsterpobrecopaspolitica(L),!.
obtieneLista(N,L) :- N = 'hipsterpobrecopasdeportes', hipsterpobrecopasdeportes(L),!.
obtieneLista(N,L) :- N = 'hipsterpobrecopasmusica', hipsterpobrecopasmusica(L),!.

% hipster  pudiente
obtieneLista(N,L) :- N = 'hipsterpudientecopaspolitica', hipsterpudientecopaspolitica(L),!.
obtieneLista(N,L) :- N = 'hipsterpudientecopasdeportes', hipsterpudientecopasdeportes(L),!.
obtieneLista(N,L) :- N = 'hipsterpudientecopasmusica', hipsterpudientecopasmusica(L),!.

% karmawhore

% copas
% karmawhore  pobre
obtieneLista(N,L) :- N = 'karmawhorepobrecopaspolitica', karmawhorepobrecopaspolitica(L),!.
obtieneLista(N,L) :- N = 'karmawhorepobrecopasdeportes', karmawhorepobrecopasdeportes(L),!.
obtieneLista(N,L) :- N = 'karmawhorepobrecopasmusica', karmawhorepobrecopasmusica(L),!.

% karmawhore  pudiente
obtieneLista(N,L) :- N = 'karmawhorepudientecopaspolitica', karmawhorepudientecopaspolitica(L),!.
obtieneLista(N,L) :- N = 'karmawhorepudientecopasdeportes', karmawhorepudientecopasdeportes(L),!.
obtieneLista(N,L) :- N = 'karmawhorepudientecopasmusica', karmawhorepudientecopasmusica(L),!.
