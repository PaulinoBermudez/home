/* 
PEC 2 Fundamentos de Inteligencia Artificial: SBR 

Simulador Absurdo de Conversaciones Incomodas: Edición Boda

Manuel F.
*/

/*
  menu.pl Archivo encargado de crear y gestionar el menú de la aplicación y los mensajes de texto.
*/

/*
  Predicados encargados del menú.
*/

% Menú Inicial

menuInicial :- write('Elige una de las siguientes opciones:'), nl, write('1. No quiero esperar, hazlo todo!'), nl, write('2. Vamos paso a paso'), nl, write('3. Reiniciar aplicación'), nl, write('4. Interprete'), nl, write('5. Salir'), nl, write('Pulsa el número de la elección escogida.'), nl, read(C), clear, (menuInicialO(C) -> (!); nl, nl, write('Opción incorrecta, vuelva a intentarlo'), nl, nl, menuInicial).

% Opciones menú inicial.

menuInicialO(1) :- clear, generaBodaAutomaticamente, clear, menuInicial.
menuInicialO(2) :- clear, menuPaso.
menuInicialO(3) :- clear, borraBoda, menuInicial .
menuInicialO(4) :- mensajeInterprete.
menuInicialO(5) :- halt.

% Menú paso a paso

menuPaso :- write('Elige una opción, pero recuerda que para las conversaciones necesitas invitados, y para estos necesitas novios y que debes borrar antes los invitados y los novios se pretendes volver a generarlos:'), nl, write('1. Genera novios'), nl, write('2. Genera invitados'), nl, write('3. Genera conversación en el vermut'), nl, write('4. Genera conversación en la cena'), nl, write('5. Genera conversación en las copas'), nl, write('6. Borra los novios (implica Borra invitados y Borra conversaciones)'), nl, write('7. Borra invitados (implica borra conversaciones)'), nl, write('8. Borra conversaciones'), nl, write('9. Atrás'), nl, write('Pulsa el número de la elección escogida.'), nl, read(C), clear, (menuPasoO(C) -> (!); nl, nl, write('Opción incorrecta, vuelva a intentarlo'), nl, nl, menuPaso).

% Opciones menú paso a paso
 
menuPasoO(1) :- clear, generaNovios, infoNovios, espera, clear, menuPaso.
menuPasoO(2) :- clear, write('Elige un número de invitados entre 2 y 30'),nl, read(N), generaInvitados(N), infoComensales, espera, clear, menuPaso.
menuPasoO(3) :- clear, menuVermut.
menuPasoO(4) :- clear, menuCena.
menuPasoO(5) :- clear, menuCopas.
menuPasoO(6) :- clear, borraBoda, menuPaso.
menuPasoO(7) :- clear, borraInvitados, menuPaso.
menuPasoO(8) :- clear, borraDicho, menuPaso.
menuPasoO(9) :- clear, menuInicial.

% Menú conversación vermut

menuVermut :- write('Elige uno de los temas disponibles:'), nl, write('1. El tiempo'), nl, write('2. Los novios'), nl, write('3, El restaurante'), nl, write('4. Aleatorio'), nl, write('5. Atrás'), nl, write('Pulsa el número de la elección escogida.'), nl, read(C), clear, (menuVermutO(C) -> (!); nl, nl, write('Opción incorrecta, vuelva a intentarlo'), nl, nl, menuVermut).

% Opciones del menú vermut

menuVermutO(1) :- clear, converVermut('tiempo'), espera,  clear, menuPaso.
menuVermutO(2) :- clear, converVermut('novios'), espera, clear, menuPaso.
menuVermutO(3) :- clear, converVermut('restaurante'), espera, clear, menuPaso.
menuVermutO(4) :- clear, temaVermut(Lvermut), elementoAzar(Lvermut,TemaV), converVermut(TemaV), espera, clear, menuPaso.
menuVermutO(5) :- clear, menuPaso.

% Menú conversación cena

menuCena :- write('Elige uno de los temas disponibles:'), nl, write('1. La política'), nl, write('2. La televisión'), nl, write('3, La comida'), nl, write('4. Aleatorio'), nl, write('5. Atrás'), nl, write('Pulsa el número de la elección escogida.'), nl, read(C), clear, (menuCenaO(C) -> (!); nl, nl, write('Opción incorrecta, vuelva a intentarlo'), nl, nl, menuCena).

% Opciones del menú cena

menuCenaO(1) :- clear, converCena('politica'), espera,  clear, menuPaso.
menuCenaO(2) :- clear, converCena('television'), espera, clear, menuPaso.
menuCenaO(3) :- clear, converCena('comida'), espera, clear, menuPaso.
menuCenaO(4) :- clear, temaCena(Lcena), elementoAzar(Lcena,TemaC), converCena(TemaC), espera, clear, menuPaso.
menuCenaO(5) :- clear, menuPaso.

% Menú conversación copas

menuCopas :- write('Elige uno de los temas disponibles:'), nl, write('1. La política'), nl, write('2. La música'), nl, write('3, Los deportes'), nl, write('4. Aleatorio'), nl, write('5. Atrás'), nl, write('Pulsa el número de la elección escogida.'), nl, read(C), clear, (menuCopasO(C) -> (!); nl, nl, write('Opción incorrecta, vuelva a intentarlo'), nl, nl, menuCopas).

% Opciones del menú copas

menuCopasO(1) :- clear, converCopas('politica'), espera, clear, menuPaso.
menuCopasO(2) :- clear, converCopas('musica'), espera, clear, menuPaso.
menuCopasO(3) :- clear, converCopas('deportes'), espera, clear, menuPaso.
menuCopasO(4) :- clear, temaCopas(Lcopas), elementoAzar(Lcopas,TemaC), converCopas(TemaC), espera, clear, menuPaso.
menuCopasO(5) :- clear, menuPaso.

/*
  Predicados relacionados con la presentación de la información en pantalla.
*/

% Presenta un mensaje de aviso y avisa al usuario de que pulse Intro.

espera :- write('\nPulse intro para continuar\n'), skip(10).

% El mensaje de bienvenida nada más iniciar la aplicación.

bienvenida :- write('Bienvenidos al Simulador Absurdo de Conversaciones Incomodas: Edición Boda, más conocido como sacieb para los amigos.\nEsta aplicación es la encargada de simular las conversaciones autistas que se producen en "LA MESA", esa maravillosa mesa donde se juntan los invitados que los novios no saben donde colocar y los comensales apenas se conocen.\nDisfrute de su estancia.\n\n').

% Presenta la información de los novios una vez creados.

infoNovios :- write('Bienvenidos a la boda de '), novia(X), nonvar(X), novio(Y), nonvar(Y), write(X), write(' y '), write(Y), write('\nEsta bonita pareja de incau...err... digo... novios espera casarse y ser felices para siempre. Como son unos siesos a los que prácticamente nadie soporta han decidido invitar a una serie de gente a las que apenas conoce para rellenar mesas del convite.\nAlgunas características de interés son:\n'), ((noviosTrabajanJuntos,write('Los novios trabajan juntos.\n'));(noviosNoTrabajanJuntos,write('Los novios no trabajan juntos.\n'))),((noviosYogaJuntos,write('Los novios van al mismo gimnasio.\n'));(noviosNoYogaJuntos,write('Los novios no van al mismo gimnasio.\n'))), ((noviosEstudiaronJuntos,write('Los novios fueron al mismo colegio.\n'));(noviosNoEstudiaronJuntos,write('Los novios no fueron al mismo colegio.\n'))),nl,nl,!.

% Presenta la información de los invitados una vez creados

infoComensales :- write('Los invitados a tan magno evento son:\n\n'), findall(X,esComensal(X),L), infoComensalesRecursivo(L, C), write(C), write('Moritori te salutant\n\n\n\n'),!.

% Predicado recursivo que va invitado por invitado y presenta su información.

infoComensalesRecursivo([],'\n') :- !.
infoComensalesRecursivo([E|R],C) :- esFemenina(E), clase(E,'Trabajo'),parteNovia(E), caracteristicas(X,Y,E), atomic_list_concat([E,' es una ',X,' y ',Y,'. Ha sido invitada porque trabaja con la novia.\n\n'],NC), infoComensalesRecursivo(R,AC),!, atom_concat(NC,AC,C).
infoComensalesRecursivo([E|R],C) :- esFemenina(E), clase(E,'Trabajo'),parteNovio(E), caracteristicas(X,Y,E), atomic_list_concat([E,' es una ',X,' y ',Y,'. Ha sido invitada porque trabaja con el novio.\n\n'],NC), infoComensalesRecursivo(R,AC),!, atom_concat(NC,AC,C).
infoComensalesRecursivo([E|R],C) :- esMasculino(E), clase(E,'Trabajo'),parteNovia(E), caracteristicas(X,Y,E), atomic_list_concat([E,' es un ',X,' y ',Y,'. Ha sido invitado porque trabaja con la novia.\n\n'],NC), infoComensalesRecursivo(R,AC),!, atom_concat(NC,AC,C).
infoComensalesRecursivo([E|R],C) :- esMasculino(E), clase(E,'Trabajo'),parteNovio(E), caracteristicas(X,Y,E), atomic_list_concat([E,' es un ',X,' y ',Y,'. Ha sido invitado porque trabaja con el novio.\n\n'],NC), infoComensalesRecursivo(R,AC),!, atom_concat(NC,AC,C).
infoComensalesRecursivo([E|R],C) :- esFemenina(E), clase(E,'Compi-yogui'),parteNovia(E), caracteristicas(X,Y,E), atomic_list_concat([E,' es una ',X,' y ',Y,'. Ha sido invitada porque va al mismo gimnasio que la novia.\n\n'],NC), infoComensalesRecursivo(R,AC),!, atom_concat(NC,AC,C).
infoComensalesRecursivo([E|R],C) :- esFemenina(E), clase(E,'Compi-yogui'),parteNovio(E), caracteristicas(X,Y,E), atomic_list_concat([E,' es una ',X,' y ',Y,'. Ha sido invitada porque va al mismo gimnasio que el novio.\n\n'],NC), infoComensalesRecursivo(R,AC),!, atom_concat(NC,AC,C).
infoComensalesRecursivo([E|R],C) :- esMasculino(E), clase(E,'Compi-yogui'),parteNovia(E), caracteristicas(X,Y,E), atomic_list_concat([E,' es un ',X,' y ',Y,'. Ha sido invitado porque va al mismo gimnasio que la novia.\n\n'],NC), infoComensalesRecursivo(R,AC),!, atom_concat(NC,AC,C).
infoComensalesRecursivo([E|R],C) :- esMasculino(E), clase(E,'Compi-yogui'),parteNovio(E), caracteristicas(X,Y,E), atomic_list_concat([E,' es un ',X,' y ',Y,'. Ha sido invitado porque va al mismo gimnasio que el novio.\n\n'],NC), infoComensalesRecursivo(R,AC),!, atom_concat(NC,AC,C).
infoComensalesRecursivo([E|R],C) :- esFemenina(E), clase(E,'Estudio'),parteNovia(E), caracteristicas(X,Y,E), atomic_list_concat([E,' es una ',X,' y ',Y,'. Ha sido invitada porque estudió con la novia.\n\n'],NC), infoComensalesRecursivo(R,AC),!, atom_concat(NC,AC,C).
infoComensalesRecursivo([E|R],C) :- esFemenina(E), clase(E,'Estudio'),parteNovio(E), caracteristicas(X,Y,E), atomic_list_concat([E,' es una ',X,' y ',Y,'. Ha sido invitada porque estudió con el novio.\n\n'],NC), infoComensalesRecursivo(R,AC),!, atom_concat(NC,AC,C).
infoComensalesRecursivo([E|R],C) :- esMasculino(E), clase(E,'Estudio'),parteNovia(E), caracteristicas(X,Y,E), atomic_list_concat([E,' es un ',X,' y ',Y,'. Ha sido invitado porque estudió con la novia.\n\n'],NC), infoComensalesRecursivo(R,AC),!, atom_concat(NC,AC,C).
infoComensalesRecursivo([E|R],C) :- esMasculino(E), clase(E,'Estudio'),parteNovio(E), caracteristicas(X,Y,E), atomic_list_concat([E,' es un ',X,' y ',Y,'. Ha sido invitado porque estudió con el novio.\n\n'],NC), infoComensalesRecursivo(R,AC),!, atom_concat(NC,AC,C).
infoComensalesRecursivo([E|R],C) :- esFemenina(E), clase(E,'Acompañante'),pareja(A,E), caracteristicas(X,Y,E), atomic_list_concat([E,' es una ',X,' y ',Y,'. Ha sido invitada porque es pareja de ',A,'.\n\n'],NC), infoComensalesRecursivo(R,AC),!, atom_concat(NC,AC,C).
infoComensalesRecursivo([E|R],C) :- esMasculino(E), clase(E,'Acompañante'),pareja(A,E), caracteristicas(X,Y,E), atomic_list_concat([E,' es un ',X,' y ',Y,'. Ha sido invitado porque es pareja de ',A,'.\n\n'],NC), infoComensalesRecursivo(R,AC),!, atom_concat(NC,AC,C).

% Frase de división entre la generación de invitados y el inicio de las conversaciones.

mensajeConversacion :- write('Vamos a comenzar con el asunto, los comensales se han sentado en su sitio, así que... FIGHT!!\n\n').

% El mensaje que presenta la conversación de vermut.

mensajeVermut :- write('Los comensales se acaban de sentar, algo inseguros se miran unos a otros mientras ocupan su sitio, mientras esperan a que comience la cena empiezan una conversación.\n\n').

% El mensaje que presenta la conversación de la cena

mensajeCena :- write('La cena avanza, los comensales mucho más cómodos hablan más deshinibidos mientras comen con fruición.\n\n').

% El mensaje que presenta la conversación de la sobremesa.

mensajeCopas :- write('La cena a terminado y los copazos campan por la mesa, las barreras se han roto y los temas más polémicos y deshinibidos se apoderan de la conversación.\n\n').

% Imprime el tema elegido de una conversación.

mensajeTema :-  write('El tema elegido es: ').

% El mensaje que se presenta cuando se sale al interprete.

mensajeInterprete :- write('Bienvenidos al interprete de sacieb, aquí podrá probar las diferentes predicados existentes en la aplicación, entre otros:\nesComensal(E), comprueba si el argumento es comensal en la boda.\nesFemenino(E), comprueba si el invitado pasado es femenino.\nesMasculino(E), comprueba si el invitado es masculino.\ntrabajanJuntos(E1,E2), comprueba si dos invitados trabajan juntos.\nestudiaronJuntos(E1,E2), comprueba si dos invitados estudiaron juntos.\nyogaJuntos(E1,E2), comprueba si dos invitados van juntos al mismo gimnasio.\ncaracterísticas(E,X,Y), muestra las características de un invitado.\n\nPara volver al menú solo tiene que teclear menuInicial.\n\n').

% Hace un clear de la pantalla.

clear :- write('\033[2J').
