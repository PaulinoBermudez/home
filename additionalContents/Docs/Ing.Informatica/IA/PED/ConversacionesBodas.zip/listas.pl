/* 
PEC 2 Fundamentos de Inteligencia Artificial: SBR 

Simulador Absurdo de Conversaciones Incomodas: Edición Boda

Manuel F.
*/

/*
  listas.pl Archivo encargado de contener las diferentes listas que utiliza la aplicación.
*/


% Listas de características.

listaCarac1(['hipster','hippie','karmawhore']).
listaCarac2(['pobre', 'pudiente']).

% Listas de nombres

nombreFemenino(['Eva', 'María', 'Hinata', 'Ana', 'Luisa', 'Federica', 'Belén', 'Leticia', 'Teresa', 'Segismunda', 'Alexia', 'Minerva', 'Sandra', 'Mercedes', 'Ataulfa','Susana']).
nombreMasculino(['Manuel', 'Diego', 'David', 'Luis', 'Federico', 'Leonardo', 'Francisco', 'Jorge', 'Raimundo', 'Moisés', 'Augusto', 'Julio', 'Felipe', 'Mariano', 'Narciso', 'José']).

% Lista de invitadores

invitadores(['Novio', 'Novia']).

% Lista de causas de invitación

causas(['Trabajo','Compi-yogui','Estudio']).

% Lista binaria

binaria(['Sí','No']).

% Lista temas.

%Vermut

temaVermut(['tiempo','novios','restaurante']).

% cena

temaCena(['politica','television','comida']).

% copas

temaCopas(['politica','musica','deportes']).

% Frases por defecto

listaDefecto(['Ejem','Uh','Me aburro','Achís','¿Donde está el vino?']).

% Entradillas

% hipster

% hipster femenino vermut

hipsterfemeninovermut(['con el carmín en la mano','con la mano en el sombrero']).

% hipster masculino vermut

hipstermasculinovermut(['atusándose la barba', 'mientras deja el móvil en la mesa']).

% hipster femenino cena

hipsterfemeninocena(['mientras se coloca al sitio las gafas de pasta', ' mientras fotografía un plato y lo sube a instagram']).

% hipster masculino cena

hipstermasculinocena(['quitándose las migas de la barba','catando el vino']).

% hipster femenino copas

hipsterfemeninocopas(['con el pelo seta encrespado','bebiendo un gin-tonic tendencia']).

% hipster masculino copas

hipstermasculinocopas(['con los tirantes en el suelo','haciéndose un selfie con el ficus']).

% hippie

% hippie femenino vermut

hippiefemeninovermut(['esparciendo olor a jazmín','poniendo un mandala en la mesa']).

% hippie masculino vermut

hippiemasculinovermut(['apartándose un mechón de la cara','agitando las pulseras de cuero en el brazo']).

% hippie femenino cena

hippiefemeninocena(['apartando toda carne del plato','colocándose al sitio la corona de flores del campo']).

% hippie masculino cena

hippiemasculinocena(['limpiándose los dedos en la servilleta','dibujando una estrella de la paz con el resto de la comida']).

% hippie femenino copas

hippiefemeninocopas(['agitando sus colgantes chinos comprados en un mercadillo','agitando los dedos de los pies descalzos']).

% hippie masculino copas

hippiemasculinocopas(['sacando la estrella de la paz del cubata','agitando las mangas bordadas de su camisa']).

% karmawhore

% karmawhore femenino vermut

karmawhorefemeninovermut(['con las gafas de sol puestas','reflejando la luz en su anillo de brillantes']).

% karmawhore masculino vermut

karmawhoremasculinovermut(['dejando su iphone bien visible en la mesa','declamando en voz alta']).

% karmawhore femenino cena

karmawhorefemeninocena(['golpeando el vaso con el tenedor','agitando el pelo']).

% karmawhore masculino cena

karmawhoremasculinocena(['golpeando la mesa con el puño','estirando la espalda y levantando la barbilla']).

% karmawhore femenino copas

karmawhorefemeninocopas(['posando para una foto imaginaria','colocándose el escote']).

% karmawhore masculino copas

karmawhoremasculinocopas(['con la corbata en la frente','encima de la mesa']).

% Listas de frases

% hipster

%Vermut

%hipster  pobre 

hipsterpobrevermuttiempo(['¡Que calor! No voy a poder llevar el abrigo de mi abuela.','Menos mal que mis gafas no tienen cristal y no se empañan.','Me he comprado un detector de lluvia mecánico, por supuesto en un mercadillo.']).

hipsterpobrevermutnovios(['No me gustan esos vestidos de diseñador, mejor hacérselo uno mismo con trozos sacados de la basura','La barba del novio es genial, seguro que no se la corta él mismo.','¡Que mal que la novia se haya quitado las gafas de pasta para casarse!']).

hipsterpobrevermutrestaurante(['Huy, con estas servilletas hago yo un vestido de boda y creo tendencia.','Este restaurante es muy chic, vaya aburrimiento.','No tienen nada oriental, si no fuera gratis me iría.']).

%hipster  pudiente

hipsterpudientevermuttiempo(['¡Hace un tiempo ideal! Así podéis ver mis profundos tatuajes.','Con este tiempo dan ganas de pagar una fortuna para comer crustáceos pescados por uno mismo.','Este cielo parece sacado de una novela de Murakami.']).

hipsterpudientevermutnovios(['Me encanta la levita que lleva el novio, como se nota que imita la de su padre el día de su boda.','¡Que cutre que no se haya puesto trencitas en la barba!','La novia va demasiado mainstream para mi.']).

hipsterpudientevermutrestaurante(['¿Aquí sirven comida paleolítica?','Este restaurante esta en todas las guías, seguro que tienen peinador de barbas.','¡Una funda para dejar nuestras falsas gafas!']).


% hippie

% vermut

%hippie  pobre 

hippiepobrevermuttiempo(['Con este tiempo me voy a asar con esta túnica de los chinos.','Estoy sudando tanto que se me va la roña.','Este calor es culpa de las perversas multinacionales.']).

hippiepobrevermutnovios(['No comparto esto de atarse, ¡Viva el amor libre!','Seguro que han asesinado tres avestruces para hacerle ese tocado.','El traje del novio parece de algodón, me alegra que haya abrazado el veganismo.']).

hippiepobrevermutrestaurante(['Aquí huele a sangre, seguro que asesinan a seres vivos con sus propias manos.','Que desperdicio de mantel, con este algodón me hago una túnica nupcial.','¿Tendrá fumadero este antro?']).

%hippie  pudiente

hippiepudientevermuttiempo(['Me encanta el calor, así podre enseñar mi Kurta bordado a mano por niños afganos.','Espero que llueva para que bailemos todos bajo ella y entremos en comunión con la naturaleza.','Espero que apaguen el aire acondicionado, este calor no es excusa para destruir nuestro planeta.']).

hippiepudientevermutnovios(['¡Que guapa estaría la novia con un sari y no esa mierda occidentalizada!','Me encantan las flores, lastima que no lleven solo eso los novios.','Con lo bonita que habría sido una boda en el desierto, todos estaríamos en comunión con la naturaleza.']).

hippiepudientevermutrestaurante(['Este restaurante no tiene para sentarse en el suelo, vaya fascistas.','Cuando era joven me encadene en este mismo salón para que dejarán en libertad los pobres camarones.','No me han dejado entrar con el perro, al menos tenían una bonita perrera.']).


% karmawhore

% vermut

%karmawhore  pobre 

karmawhorepobrevermuttiempo(['Me encanta este tiempo, puedo lucir escotazo.','¡¡¡Camarero!!! ¡Dale más marcha al aire acondicionado.!','Estoy seguro de que va a llover, tengo un sexto sentido infalible para ello, incluso me llaman de Antena 3 para consultarme.']).

karmawhorepobrevermutnovios(['Vaya cutres, ¿donde está la pedrería cegadora?','Este novio no da para presumir, es más feo que un cenicero.','En mi boda iba más guapa que la novia hasta la señora de la limpieza.']).

karmawhorepobrevermutrestaurante(['¡Anda! Nos han puesto agua con limón para refrescarnos el aliento.','Yo trabajé en un sitio como este, no comáis la sopa de cebolla, no siempre lleva cebolla... ya me entendéis.','¡¡¡Camarero!!! Sáqueme otra servilleta, esta esta llena de mocos.']).

%karmawhore  pudiente

karmawhorepudientevermuttiempo(['Con este sol los diamantes de mis dientes brillan más.','Uff, que calor que hace aquí, vengo directamente del aeropuerto de esquiar en nieve virgen en los Andes.','Mi buen amigo Roberto Brasero ya me había avisado de que vistiera de manguita corta.']).

karmawhorepudientevermutnovios(['Anda, que copiones, llevan un traje como el mio estos novios.','Si no tenían contactos con cartier podrían haberme avisado, una boda sin un diamante de 100 kilates no es boda.','Que don nadie son los novios, no hay otro famoso como yo en esta boda.']).

karmawhorepudientevermutrestaurante(['¡Tenemos wifi!, podre tuitear todo lo que hagamos.','Me encanta que haya un espejo en esa pared, así todo el mundo puede observar mi maravillosa presencia.','Este restaurante es chic, pero yo y mis amigos estamos acostumbrados a sitios exclusivos.']).


% hipster

% cena

%hipster  pobre 

hipsterpobrecenapolitica(['Yo solo voto a aquellos candidatos que lleven barba.','Yo solo voto a la gente que marque tendencia, aunque sea absurda. Albert Ribera es muy chic.','Me encanta la ropa antigua, Rajoy es mi ídolo.']).

hipsterpobrecenatelevision(['A mi me encantan las series, pero desde que mi vecino ha cerrado el wifi no veo nada.','Ya no hacen series como "Verano azul", ahora en la tele solo hacen cosas para gañanes.','Me encantan los programas de Divinity, son tan cools.']).

hipsterpobrecenacomida(['Si no tienen cupcakes de postre es para matarlos.','Menos mal que me he traído un taper, esto esta de muerte.','Yo me hago esto en mi casa, cocinar es el nuevo sexo.']).

%hipster  pudiente

hipsterpudientecenapolitica(['Me encanta lo antiguo, Alberto Garzón tiene un aire a los 80 que me apasiona.','Albert Ribera es mi alma gemela, marcamos tendencia allí donde vamos.','¡Esto se tiene que acabar! Hace falta una revolución en el parlamento ¡Vivan las barbas!']).

hipsterpudientecenatelevision(['Yo todo lo veo en VO, luego lo tengo que volver a ver para enterarme, pero no hay color.','Soy muy fan de "MasterChef", me he tenido que comprar todo el conjunto de cocina para poder imitarles.','Me dan asco las tertulias políticas, sale gente que no sabe nada de las tendencias.']).

hipsterpudientecenacomida(['Habría preferido menú vietnamita-finlandés con toques de congoleño, pero no esta mal.','Podrían venir antes a por los platos, una vez los he subido a instagram ya no importa.','Yo soy partidario de comer la comida étnica en su hábitat, que más da tragarse 12 horas de avión para comer un perrito caliente.']).


% hippie

% cena

%hippie  pobre 

hippiepobrecenapolitica(['Tenemos que votar a aquellos que defienden el planeta, yo solo voto a los que van en bici.','Yo soy mucho de Climent, el ha visto la luz y seguro que se pasa los petas.','Las elecciones son un aquelarre de mafiosos, pero así se me hace más fácil transportar la maría, están todos los polis ocupados.']).

hippiepobrecenatelevision(['Yo no tengo televisión, no las hacen de cáñamo.','A mi solo me gusta "Supervivientes" y "Aventura en taparrabos", me recuerdan a mis temporadas en el pueblo.','"Cuarto milenio" es la caña, de ahí saco todos mis conocimientos científicos.']).

hippiepobrecenacomida(['Llevo dos semanas comiendo solo arroz para aprovechar esto.','Yo solo como con las manos, es como lo hacían nuestros ancestros en la vida natural.','No sabía que esto se comía, no hay nada como esto en el Lidl.']).

%hippie  pudiente

hippiepudientecenapolitica(['Lo que deberíamos hacer es aprender de los Hare-krishna, todo el día cantando y se arregla todo.','Yo solo voto a aquellos partidos que tienen su papeleta en papel reciclado biodegradable.','Yo no tengo mucho interés en la política, no se preocupan de lo importante, como los pajaritos.']).

hippiepudientecenatelevision(['Yo solo tengo la televisión para poner paisajes adecuados para la meditación.','En la comuna solo teníamos una tele y se veía un único canal, total, fumado es suficiente.','La televisión es muy poco ecologista, necesitamos más programas que tengan un ficus como presentador.']).

hippiepudientecenacomida(['Yo solo como vegano con certificado de no sufrimiento, seguro que esta lechuga no ha sido anestesiada antes de su recolección.','Esta comida seguro que no es de un mercado de proximidad, tiene pinta de artificial.','¡Salvajes! Vamos a rezar por el alma del cerdo que os estáis comiendo.']).

% karmawhore

% cena

%karmawhore  pobre 

karmawhorepobrecenapolitica(['Yo estoy en un circulo de Podemos.. ¿o era en una lista de Ciudadanos?','Yo voy a todos los mítines, me pongo en primera fila y robo una cartera, a ver si me descubre algún cazatalentos.','Al final, da igual que partido elegir, lo importante es tener buenos enchufes. Como mi cuñado.']).

karmawhorepobrecenatelevision(['A mi me encantan los concursos, he estado de público en casi todos. ¡Sales por la tele y te dan un bocadillo!','El sueño de mi vida es ir a "Gran hermano", ahí si que te haces famoso de verdad.','Yo si no salen tetas y culos apago la tele.']).

karmawhorepobrecenacomida(['Estas pijadas siempre me dejan con hambre: ¡¡¡Camarero!!! ¡Tráigame una barra de pan!','Yo solo me como lo que puedo matar.','Vaya mierda, cada vez dan menos gambas.']).

%karmawhore  pudiente

karmawhorepudientecenapolitica(['Yo me he presentado a las elecciones varias veces, pero ahora no recuero como se llamaba el partido.','La política es para inferiores, yo prefiero dedicarme al noble arte de la corrupción.','Yo cuando ceno con Rita y Carlos siempre les digo que más tendrían que haber mangado.']).

karmawhorepudientecenatelevision(['A mi me encantan los programas esos de las casas, ya me he cambiado de casa dos veces para poder repetir.','Yo solo tengo Telecinco sintonizado, allí hacen todo lo que me gusta.','Los de Sálvame son muy simpáticos, los veo en todas las fiestas y siempre me sacan en las revistas.']).

karmawhorepudientecenacomida(['Esta comida tiene muy poca calidad, mi perro come mejor.','El otro día estaba cenando con Ferran, lastima que los novios no hayan hablado conmigo.','!!!Camarero¡¡¡ ¡Mi plato tiene un pelo!']).

% hipster

% Copas

%hipster  pobre 

hipsterpobrecopaspolitica(['¡¡Hace falta una frondosa barba que nos guíe a la revolución!!','¡¡¡PODEMOS!!! Falta menos para que muera el mainstream.','Yo voto al partido más raro, seguro que con ellos pasan cosas nuevas.']).

hipsterpobrecopasdeportes(['Hacer deporte se ha vuelvo muy mainstream, yo prefiero pegarme martillazos en el pie.','¡No hay nada como la tala de arboles! Es el deporte del futuro.','A mi me encanta practicar deporte de riesgo, por eso vivo en un cuarto sin ascensor.']).

hipsterpobrecopasmusica(['A ver si ponen a David Guetta, me encanta la música artesanal.','¡Vivan los ukeleles!','Si estiro mi barba igual puedo hacerla sonar como un violín.']).

%hipster  pudiente

hipsterpudientecopaspolitica(['Agitemos nuestras gafas, Albert nos llevará al paraíso liberal.','Podemos ya es demasiado mainstream, yo ahora voto al Partido Carlista','¡Es hora de coger nuestros mosquetones! ¡Que no quede ni uno!']).

hipsterpudientecopasdeportes(['Yo solo veo deportes que no salgan en el periódico, son más puros.','El deporte esta sobrevalorado, yo prefiero peinar barbas.','Hay que correr como nuestros abuelos, con la policía detrás para ser autentico.']).

hipsterpudientecopasmusica(['La melodía esta sobrevalorada, lo mejor son sonido átonos e inconexos.','Yo solo escucho grupos sin disco, cuando publican es el momento de quemar todo lo que tengo de ellos.','ZZTop mola, se nota que son contraculturales, llevan barba.']).

% hippie

% copas

%hippie  pobre 

hippiepobrecopaspolitica(['Vayámonos todos a vivir al campo y los políticos en un cercado.','Viva el partido de la maría, esos si que saben.','¡Vamos a hacer la guerra para luego hacer el amor!... o algo así.']).

hippiepobrecopasdeportes(['Yo solo corro detrás de mis perros.','Yo solo hago deporte cuando me ve la policía fumando porros.','A mi me gusta hacer deporte, el problema es que sudo y me canso.']).

hippiepobrecopasmusica(['"No guoman no gay" ¡Viva la música de verdad!','Vamos a bailar sobre la hierba... o con la hierba, que más da.','La música me agobia, prefiero escuchar un concierto de pedos.']).

%hippie  pudiente

hippiepudientecopaspolitica(['Yo soy del partido animalista, ¡Deberían dejarnos cazar humanos!','Nada como Podemos, "Coleta morada" nos pone en comunicación con nuestro espíritu.','Pdr Snchz parece que lleve un palo en el culo, seguro que si se viene a nuestra comuna anual le cambiamos la cara.']).

hippiepudientecopasdeportes(['El deporte solo está para alienar al populacho, yo prefiero el Hare Krishna.','Yo solo hago deportes naturistas, si no se puede hacer en pelotas no es deporte ni nada.','Los futbolistas deberían dar ejemplo y enseñarnos su tercer ojo.']).

hippiepudientecopasmusica(['Yo solo escucho los mejores músicos relajantes, ¡hay que luchar a brazo partido para ponerse en la primera fila!','¡Ojala hayan traído una banda de peruanos!','¡Bailemos desnudos al son de la música!']).

% karmawhore

% copas

%karmawhore  pobre 

karmawhorepobrecopaspolitica(['Si yo mandara se acababan las tonterías en segundos, solo necesito una escopeta.','¡Estoy harto de chupopteros! Hay que echar a los corruptos y meter a alguno que conozca yo.','¡Viva Ciudadanos! Hay que renovar la cantera, esos todavía no tienen amigos del alma.']).

karmawhorepobrecopasdeportes(['Yo solo veo el deporte donde ganamos, si no ganamos pasan a ser una mierda.','Menos mal que mi cuñao me ha pirateado el plus, ¡No se puede vivir sin fútbol!','El otro día conocía Cristiano, freno y todo cuando me vio encima del capó.']).

karmawhorepobrecopasmusica(['¡¡¡¡¡Booooombaaaaaaaa!!!!!','Hay que menear el culo, ¡Dale al reguetoon!','¿Donde esta el podio? ¡Hay que darlo todo!']).

%karmawhore  pudiente

karmawhorepudientecopaspolitica(['Ya lo dice Rus, ¡hay que celebrarlo con champagne y mujeres!','No os preocupéis, si tenéis algún problema un par de llamadas a mis amigos y solucionado.','Mucha revolución y pollas, pero al final todos a votar al PP, como Dios manda.']).

karmawhorepudientecopasdeportes(['Cuando decís deporte, os referís a fútbol,¿no?','El fútbol se ve diferente en el palco junto Floren.','Cristiano es el mejor, en su jet privado se sirven unos copazos ideales para romper tarima.']).

karmawhorepudientecopasmusica(['¡¡Viva la Carrá!!','Yo siempre tengo entrada al backstage, cuando queráis un autógrafo pedídmelo.','¡Soy el dios de las pistas de baile!']).
