/* 
PEC 2 Fundamentos de Inteligencia Artificial: SBR 

Simulador Absurdo de Conversaciones Incomodas: Edición Boda

Manuel F.
*/

/*
  sacieb.pl Archivo encargado de los principales predicados de la aplicación y los predicados dinámicos.
*/

% Da una bienvenida, carga el resto de archivos, inicializa la lista de frases dichas y arranca el menú inicial.

sacieb :- consult('listas.pl'), consult('auxiliar.pl'), consult('menu.pl'), assert(listaDicho([''])),bienvenida, nl, nl, menuInicial.

/*
  Los predicados posteriores son los generadores de la lógica de la aplicación.
*/

% Genera una boda, los invitados y todas las conversaciones seguidas.

generaBodaAutomaticamente :- generaNovios, infoNovios, espera, generaInvitados(6), infoComensales, mensajeConversacion, espera, temaVermut(Lvermut), elementoAzar(Lvermut,TemaV), converVermut(TemaV), espera, temaCena(Lcena), elementoAzar(Lcena,TemaCe), converCena(TemaCe), espera, temaCopas(Lcopas),elementoAzar(Lcopas,TemaCo), converCopa(TemaCo),espera,!.

% Genera conversación del vermut del tema pasado.

converVermut(TemaV) :- findall(X,esComensal(X),Comensales), baraja(Comensales,C1), conversacion(C1, 'vermut', TemaV,ConV), mensajeVermut, mensajeTema, write(TemaV), nl, nl, write(ConV),!.

% Genera conversación de la cena del tema pasado.

converCena(TemaCe) :- findall(X,esComensal(X),Comensales), baraja(Comensales,C2), conversacion(C2, 'cena', TemaCe,ConCe), mensajeCena, mensajeTema, write(TemaCe), nl, nl, write(ConCe).

% Genera conversación de las copas del tema pasado.

converCopa(TemaCo) :- findall(X,esComensal(X),Comensales), baraja(Comensales,C3),conversacion(C3, 'copas', TemaCo,ConCo), mensajeCopas, mensajeTema, write(TemaCo), nl, nl, write(ConCo).

% Inicia y genera los novios. 

generaNovios :- borraBoda, nombreFemenino(Fem), elementoAzar(Fem,Novia), assert(novia(Novia)),eliminaElemento(Novia,Fem,NFem), assert(nuevoNombreFemenino(NFem)), nombreMasculino(Mas), elementoAzar(Mas,Novio), assert(novio(Novio)),eliminaElemento(Novio,Mas,NMas), assert(nuevoNombreMasculino(NMas)), binaria(Binario),elementoAzar(Binario,Btrabajo),((Btrabajo='No', assert(noviosNoTrabajanJuntos));(Btrabajo='Sí', assert(noviosTrabajanJuntos))),elementoAzar(Binario,Bestudio),((Bestudio='No', assert(noviosNoEstudiaronJuntos));(Bestudio='Sí', assert(noviosEstudiaronJuntos))), elementoAzar(Binario,Byoga),((Byoga='No', assert(noviosNoYogaJuntos));(Byoga='Sí', assert(noviosYogaJuntos))),!.

% Genera los comensales.

generaInvitados(Num) :- borraInvitados, nuevoNombreFemenino(Fem), nuevoNombreMasculino(Mas), concatena(Fem,Mas,Base), divideNum(Num,P,S), generarParejas(P,Base,NBase), generarSolteros(S,NBase),!.

% Genera el número de solteros pasado y los añade a la lista pasada.

generarSolteros(Num,_):- Num = 0.
generarSolteros(Num, Base) :- elementoAzar(Base,E), eliminaElemento(E,Base,NBase), invitadores(Novios), elementoAzar(Novios,Parte), causas(Causas), elementoAzar(Causas,Causa), ((Parte = 'Novia',assert(parteNovia(E)));(Parte = 'Novio',assert(parteNovio(E)))), assert(clase(E,Causa)), generaCaract(E), res(Num,1,NNum), assert(esComensal(E)), generarSolteros(NNum,NBase). 

% Genera el número de parejas pasado y los añade a la lista pasada.

generarParejas(Num, Base, Base):- Num = 0,!.
generarParejas(Num, Base, NBase) :- invitadores(Novios), elementoAzar(Novios,Parte), causas(Causas), elementoAzar(Causas,Causa), elementoAzar(Base,E), eliminaElemento(E,Base,ABase), elementoAzar(ABase,E2), eliminaElemento(E2,ABase,A2Base), assert(pareja(E,E2)), ((Parte = 'Novia',assert(parteNovia(E)),assert(parteNovia(E2)));(Parte = 'Novio',assert(parteNovio(E)),assert(parteNovio(E2)))), assert(clase(E,Causa)),assert(clase(E2,'Acompañante')), generaCaract(E), generaCaract(E2), res(Num,1,NNum), assert(esComensal(E)), assert(esComensal(E2)), generarParejas(NNum, A2Base, NBase).

% Genera características de un comensal.

generaCaract(E) :- listaCarac1(L1), elementoAzar(L1,C1), assert(esCaract1(C1,E)), listaCarac2(L2), elementoAzar(L2,C2), assert(esCaract2(C2,E)), !.

/*
  Los predicados posteriores son los encargados de reiniciar la BC a un estado en concreto.
*/

% Elimina todos los hechos insertados dinámicamente.

borraBoda :- novio(X), nonvar(X), retract(novio(_)), retract(novia(_)), retract(nuevoNombreMasculino(_)), retract(nuevoNombreFemenino(_)), retractall(noviosNoTrabajanJuntos), retractall(noviosTrabajanJuntos),  retractall(noviosNoEstudiaronJuntos), retractall(noviosEstudiaronJuntos), retractall(noviosYogaJuntos), retractall(noviosNoYogaJuntos), borraInvitados,!.
borraBoda :- !.

% Elimina los comensales y todos los hechos relacionados con ello.

borraInvitados :- esComensal(L), nonvar(L), retractall(esComensal(_)), retractall(parteNovia(_)), retractall(parteNovio(_)), retractall(clase(_,_)), retractall(pareja(_,_)), retractall(esCaract1(_,_)), retractall(esCaract2(_,_)), borraDicho, !.
borraInvitados :- !.

% Borra las frases dichas.

borraDicho :- retract(listaDicho(_)), assert(listaDicho([''])),!.

/*
 Predicados varios para consultar.
*/
 
% Comprueba si un elemento es masculino

esMasculino(E) :- esComensal(E), nombreMasculino(L), member(E,L). 

% Comprueba si un elemento es femenino.

esFemenina(E) :- esComensal(E), nombreFemenino(L), member(E,L).

% Devuelve las características de un elemento

caracteristicas(X,Y,E) :- esCaract1(X,E), esCaract2(Y,E).

% Comprueba si dos elementos trabajan juntos.

trabajanJuntos(X,Y) :- dif(X,Y), parteNovio(X),clase(X,'Trabajo'), parteNovio(Y),clase(Y,'Trabajo').
trabajanJuntos(X,Y) :- dif(X,Y), parteNovia(X),clase(X,'Trabajo'), parteNovia(Y),clase(Y,'Trabajo').
trabajanJuntos(X,Y) :- dif(X,Y), novio(X), parteNovio(Y),clase(Y,'Trabajo').
trabajanJuntos(X,Y) :- dif(X,Y), novia(X), parteNovia(Y),clase(Y,'Trabajo').
trabajanJuntos(X,Y) :- dif(X,Y), parteNovio(X),clase(X,'Trabajo'), novio(Y).
trabajanJuntos(X,Y) :- dif(X,Y), parteNovia(X),clase(X,'Trabajo'), novia(Y).
trabajanJuntos(X,Y) :- dif(X,Y), noviosTrabajanJuntos, parteNovio(X),clase(X,'Trabajo'), parteNovia(Y),clase(Y,'Trabajo').
trabajanJuntos(X,Y) :- dif(X,Y), noviosTrabajanJuntos, parteNovia(X),clase(X,'Trabajo'), parteNovio(Y),clase(Y,'Trabajo').
trabajanJuntos(X,Y) :- dif(X,Y), noviosTrabajanJuntos, novio(X), parteNovia(Y),clase(Y,'Trabajo').
trabajanJuntos(X,Y) :- dif(X,Y), noviosTrabajanJuntos, novia(X), parteNovio(Y),clase(Y,'Trabajo').
trabajanJuntos(X,Y) :- dif(X,Y), noviosTrabajanJuntos, parteNovio(X),clase(X,'Trabajo'), novia(Y).
trabajanJuntos(X,Y) :- dif(X,Y), noviosTrabajanJuntos, parteNovia(X),clase(X,'Trabajo'), novio(Y).
trabajanJuntos(X,Y) :- dif(X,Y), noviosTrabajanJuntos, novia(X), novio(Y).
trabajanJuntos(X,Y) :- dif(X,Y), noviosTrabajanJuntos, novio(X), novia(Y).

% Comprueba si dos elementos estudiaron juntos.

estudiaronJuntos(X,Y) :- dif(X,Y), parteNovio(X),clase(X,'Estudio'), parteNovio(Y),clase(Y,'Estudio').
estudiaronJuntos(X,Y) :- dif(X,Y), parteNovia(X),clase(X,'Estudio'), parteNovia(Y),clase(Y,'Estudio').
estudiaronJuntos(X,Y) :- dif(X,Y), novio(X), parteNovio(Y),clase(Y,'Estudio').
estudiaronJuntos(X,Y) :- dif(X,Y), novia(X), parteNovia(Y),clase(Y,'Estudio').
estudiaronJuntos(X,Y) :- dif(X,Y), parteNovio(X),clase(X,'Estudio'), novio(Y).
estudiaronJuntos(X,Y) :- dif(X,Y), parteNovia(X),clase(X,'Estudio'), novia(Y).
estudiaronJuntos(X,Y) :- dif(X,Y), noviosEstudiaronJuntos, parteNovio(X),clase(X,'Estudio'), parteNovia(Y),clase(Y,'Estudio').
estudiaronJuntos(X,Y) :- dif(X,Y), noviosEstudiaronJuntos, parteNovia(X),clase(X,'Estudio'), parteNovio(Y),clase(Y,'Estudio').
estudiaronJuntos(X,Y) :- dif(X,Y), noviosEstudiaronJuntos, novio(X), parteNovia(Y),clase(Y,'Estudio').
estudiaronJuntos(X,Y) :- dif(X,Y), noviosEstudiaronJuntos, novia(X), parteNovio(Y),clase(Y,'Estudio').
estudiaronJuntos(X,Y) :- dif(X,Y), noviosEstudiaronJuntos, parteNovio(X),clase(X,'Estudio'), novia(Y).
estudiaronJuntos(X,Y) :- dif(X,Y), noviosEstudiaronJuntos, parteNovia(X),clase(X,'Estudio'), novio(Y).
estudiaronJuntos(X,Y) :- dif(X,Y), noviosEstudiaronJuntos, novia(X), novio(Y).
estudiaronJuntos(X,Y) :- dif(X,Y), noviosEstudiaronJuntos, novio(X), novia(Y).

% Comprueba si dos elementos fueron juntos al gimnasio.

yogaJuntos(X,Y) :- dif(X,Y), parteNovio(X),clase(X,'Compi-yogui'), parteNovio(Y),clase(Y,'Compi-yogui').
yogaJuntos(X,Y) :- dif(X,Y), parteNovia(X),clase(X,'Compi-yogui'), parteNovia(Y),clase(Y,'Compi-yogui').
yogaJuntos(X,Y) :- dif(X,Y), novio(X), parteNovio(Y),clase(Y,'Compi-yogui').
yogaJuntos(X,Y) :- dif(X,Y), novia(X), parteNovia(Y),clase(Y,'Compi-yogui').
yogaJuntos(X,Y) :- dif(X,Y), parteNovio(X),clase(X,'Compi-yogui'), novio(Y).
yogaJuntos(X,Y) :- dif(X,Y), parteNovia(X),clase(X,'Compi-yogui'), novia(Y).
yogaJuntos(X,Y) :- dif(X,Y), noviosYogaJuntos, parteNovio(X),clase(X,'Compi-yogui'), parteNovia(Y),clase(Y,'Compi-yogui').
yogaJuntos(X,Y) :- dif(X,Y), noviosYogaJuntos, parteNovia(X),clase(X,'Compi-yogui'), parteNovio(Y),clase(Y,'Compi-yogui').
yogaJuntos(X,Y) :- dif(X,Y), noviosYogaJuntos, novio(X), parteNovia(Y),clase(Y,'Compi-yogui').
yogaJuntos(X,Y) :- dif(X,Y), noviosYogaJuntos, novia(X), parteNovio(Y),clase(Y,'Compi-yogui').
yogaJuntos(X,Y) :- dif(X,Y), noviosYogaJuntos, parteNovio(X),clase(X,'Compi-yogui'), novia(Y).
yogaJuntos(X,Y) :- dif(X,Y), noviosYogaJuntos, parteNovia(X),clase(X,'Compi-yogui'), novio(Y).
yogaJuntos(X,Y) :- dif(X,Y), noviosYogaJuntos, novia(X), novio(Y).
yogaJuntos(X,Y) :- dif(X,Y), noviosYogaJuntos, novio(X), novia(Y).

/*
  Predicados que sirven para crear las conversaciones.
*/

%Conversación

conversacion([],_,_,''):-!.
conversacion([E|R], Tiempo, Tema, Conversacion) :- entradilla(E, Tiempo, Entrada), frase(E, Tema, Tiempo, Frase), conversacion(R, Tiempo, Tema, AConversacion), !, atom_concat(E,', ',E2), atom_concat(E2, Entrada, E2E), atom_concat(E2E, ', dice:\n', E2E2), atom_concat(E2E2, Frase, E2E2F), atom_concat(E2E2F, '\n\n', E2E2F2), atom_concat(E2E2F2,AConversacion, Conversacion). 

%Entradilla de un comensal en un tiempo en concreto.

entradilla(E, Tiempo, Entrada) :- esFemenina(E),caracteristicas(C1,_,E), atom_concat(C1, 'femenino', C1F), atom_concat(C1F, Tiempo, C1FTiempo), obtieneEntrada(C1FTiempo, L), elementoAzar(L, Entrada),!.
entradilla(E, Tiempo, Entrada) :- esMasculino(E),caracteristicas(C1,_,E), atom_concat(C1, 'masculino', C1F), atom_concat(C1F, Tiempo, C1FTiempo), obtieneEntrada(C1FTiempo, L), elementoAzar(L, Entrada),!.

%Frase de un comensal de un tema en concreto en un tiempo en concreto

frase(E,Tema, Tiempo, Frase) :- caracteristicas(C1, C2, E), atom_concat(C1, C2, C1C2),  atom_concat(C1C2, Tiempo, C1C2Tiempo), atom_concat(C1C2Tiempo, Tema, C1C2TiempoTema), obtieneLista(C1C2TiempoTema, L), baraja(L,NL), eligeFrase(NL, Frase),!. 

%Obtiene la primera frase no dicha de una lista, o presenta una de las frases por defecto.

eligeFrase([],Frase) :- listaDefecto(L), elementoAzar(L,Frase).
eligeFrase([Frase|_],Frase) :- listaDicho(L), noEstaElemento(Frase,L), addElement(Frase,L,NL), retract(listaDicho(_)), assert(listaDicho(NL)).
eligeFrase([X|R],Frase) :- listaDicho(L), member(X,L), eligeFrase(R,Frase).

/*
  Predicados dinámicos
*/
  
:- dynamic
novia/1,novio/1,nuevoNombreFemenino/1,nuevoNombreMasculino/1,esComensal/1,parteNovia/1,parteNovio/1,clase/2,pareja/2,esCaract1/2, esCaract2/2,  noviosTrabajanJuntos/0,noviosNoTrabajanJuntos/0,noviosEstudiaronJuntos/0,noviosNoEstudiaronJuntos/0, noviosYogaJuntos/0, noviosNoYogaJuntos/0,listaDicho/1.
