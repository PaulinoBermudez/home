/********************************************/
/**** Nombre_archivo: caturday.pl        ****/
/**** Practica FIA Proyecto Prolog       ****/
/**** Tema: Mascotas y Un Dia de tu Vida ****/
/**** Curso 15/16                        ****/
/**** Autor: David Pastor Sanz           ****/
/********************************************/

% constantes
% acciones que realiza el gato y momentos del dia
despertar.
aranar.
desayunar.
correr.
jugar.
comer.
dormir.
ronronear.
siesta.
ensuciar.
romper.
reganar.
cazar.
buscar.
hurtar.
pediguenar.
escapar.
manana.
comida.
tarde.
actividad.
destrozar.
aburrido.
trepar.

% predicados dinamicos
:- dynamic nivel/1, gato/1, accion/1, acciones/1, dueno/1.

% hechos sin variables. Son dinamicas, se iran anadiendo hechos durante la realizacion del juego
acciones([despertar]).
accion(despertar).
dueno(iniciar).

% hechos con variable
% Actualiza la lista de las acciones realizadas.
anadirAccion(NUEVA_ACCION,LISTA_ACCIONES,[NUEVA_ACCION|LISTA_ACCIONES]).
%Devuelve el numero introducido como pimer parametreo mas uno
masUno(X,X+1).

% Constante para borrar la pantalla
borrarPantalla :- write('\033[2J').

% Agrega el nombre del gato, solo es posible en el menu de inicio. Hecho con variable
nombre(X) :- nivel(inicio), assert(gato(X)).

% Hace una pausa hasta que el usuario pulse enter
pausar :- write("Pulsa <Enter> para continuar"),
          skip(10), skip(10), nl.
	  
% Predicado recursivo, imprime la lista de acciones realizadas durante el dia del felino
accionesRealizadas([])     :- write("Ninguna accion realizada"), !.
accionesRealizadas([P|[]]) :- write(P), nl, !.
accionesRealizadas([P|R])  :- accionesRealizadas(R),
			      write(P), nl.
			     
% comprueba si la lista de accione contiene la accion introducida como parametro
contiene(_,[])                :- fail, !.
contiene(ACCION,[ACCION|_])   :- !.
contiene(ACCION,[_|RESTO])    :- contiene(ACCION,RESTO).

% Devuelve un numero aleatorio entre 1 y 10. Usa el operador aritmetico
suerte(X) :- Y is random(10), masUno(Y,X).

% Anade una nueva accion realizada a la base del conocimiento
agregar(ACCION) :- acciones(X),
		   anadirAccion(ACCION,X,Y),
		   retract(acciones(_)),
		   assert(acciones(Y)).

% imprime una linea de separacion
separador :- write("-----------------------(  =^..^=  )-----------------------"), nl.


%devuelve verdadero si el dueno esta enfadado con el felino. Estara enfadado si ha realizado dos acciones malas
duenoEnfadado :- dueno(romper), dueno(aranar);
                 dueno(destrozar), dueno(aranar);
		 dueno(romper), dueno(destrozar);
		 dueno(romper), dueno(ensuciar);
		 dueno(ensuciar), dueno(aranar);
		 dueno(ensuciar), dueno(destrozar).

% predicado que muestra el inicio del juego
inicio_juego :- borrarPantalla,
                assert(nivel(inicio)), nl,
                write('                         CATURDAY!         '), nl, nl,
                write("                          (\\_ _/)          "), nl,
                write("                          (='.'=)          "), nl,
		write('                          (")_(")          '), nl, nl,
		write('Vamos a experimentar un dia en la vida de un pequeno minino'), nl, nl,
		write('Introduce el nombre de tu mascota favorita'), nl, nl,
		read(NOMBRE),
	        nombre(NOMBRE),
	        retract(nivel(inicio)),
		assert(nivel(despertar)), !.

% predicados para la ejecucion secuencia de la aventura. Para que se cumplan estos debe estar metido el hecho nivel(X) dentro de la BC
% donde X se va incluyendo dinamicamente en la BC según se avanza en la aventura
% predicado de comienzo, el gato despierta	
texto(MOMENTO,NOMBRE):-  nivel(despertar),
                         MOMENTO == despertar,
                         nl, write(NOMBRE),
		         write(" se acaba de despertar, estira sus patitas y bosteza..."), nl,
		         write("MIIIIIAAAAAUUUUU!!!!!"), nl, nl,
			 write(NOMBRE),
		         write(" no tiene comida en su cuenco, necesita consegui comida!!"), nl, nl,
		         retract(nivel(despertar)),
		         assert(nivel(1)), !.
 
% predicado que realiza la accion de desayunar del gato
texto(MOMENTO,NOMBRE) :- nivel(1),
                         MOMENTO == desayunar,
                         write("Escribe una de las siguientes opciones:"), nl, nl,
	                 write(" - 'despertar': arana un poco a su dueno para que le de su comida favorita"), nl,
		         write(" - 'buscar'   : hurgar en la bolsa de la basura en busca de una loncha de jamon"), nl,
		         write(" - 'cazar'    : buscar un raton por la casa"), nl, nl,
		         read(OPCION),
		         suerte(SUERTE),
                         opciones(desayunar,OPCION,NOMBRE,SUERTE), !.
		    
% el gato duerme despues de desayunar o no
texto(MOMENTO,NOMBRE) :- nivel(2),
			 accion(desayunar),
			 MOMENTO == manana,
                         write(NOMBRE),
			 write(" ahora que tiene el estomago lleno es hora de echar una siestecita de nuevo!!"), nl,
			 sleep(1),
			 write("zzz..."),
			 write(" ...zzzZz..."),
			 write("...zzz..."), nl,
			 write("esto si que es vida!!"), nl, nl,
			 agregar(siesta),
			 assert(accion(siesta)), !.

texto(MOMENTO,NOMBRE) :- nivel(2),
                         MOMENTO == manana,
                         write("El pobre "), write(NOMBRE),
			 write(" no ha podido desayunar, asi que decide echarse una siestecita mananera"), nl,
			 sleep(1),
			 write("zzz..."),
			 write(" ...zzzZz..."),
			 write("...zzz..."), nl,
			 write("esto si que es vida!!"), nl, nl,
			 agregar(siesta),
			 assert(accion(siesta)), !.

% hora de la comida
texto(MOMENTO,NOMBRE) :- nivel(3),
                         MOMENTO == comida,
                         write(NOMBRE),
			 write(" se acaba de despertar de su siesta matinal"), nl,
			 write("como no iba a ser, con hambre... vamos a ver que puede rapinar..."), nl, nl, !.
			
texto(MOMENTO,NOMBRE) :- nivel(3),
                         MOMENTO == comer,
                         write("Escribe una de las siguientes opciones:"), nl, nl,
	                 write(" - 'hurtar'       : su dueno esta cocinando, robarle un trozo de pollo en un momento de despiste"), nl,
		         write(" - 'pediguenar'   : pedir al dueno que le de de comer"), nl,
		         write(" - 'escapar'      : salir por la ventana en busca de algun manjar en casa del vecino"), nl, nl,
	                 read(OPCION),
		         suerte(SUERTE),
                         opciones(comer,OPCION,NOMBRE,SUERTE), !.

% siesta			 
texto(MOMENTO,NOMBRE) :- nivel(4),
                         MOMENTO == siesta,
                         accion(comer),
			 write(NOMBRE),
			 write(" tiene una vida muy estresante y agotadora, por ello necesita echarse otra siesta despues de comer..."), nl, nl, !.
			 
texto(MOMENTO,NOMBRE) :- nivel(4),
                         MOMENTO == siesta,
			 write("Despues de quedarse sin nada que llevarse a la boca "), write(NOMBRE),
			 write(" decide dormir un rato para olvidar lo ocurrido y para sonar con un cuenco de comida lleno..."), nl, nl, !.

% actividades			 
texto(MOMENTO,NOMBRE) :- nivel(5),
                         MOMENTO == tarde,
			 write(NOMBRE),
			 write(" despierta de su siesta....MIIIIIAAAAAUUUUU!!!!!!"), nl,
			 write("piensa que como continue asi se convertira en un orondo felino, asi q decide realizar alguna actividad"), nl, nl, !.
			
texto(MOMENTO,NOMBRE) :- nivel(5),
                         MOMENTO == actividad,
                         write("Escribe una de las siguientes opciones:"), nl, nl,
	                 write(" - 'aluminio'     : buscar las bolitas de alumino que hay rondando por la casa y jugar con ellas"), nl,
		         write(" - 'manicura'     : corretear por toda la casa y aranar los muebles para tener unas unas bonitas y sanas"), nl,
		         write(" - 'trepar'       : subirse por las cortinas para tener una mejor panoramica del salon"), nl, nl,
		         read(OPCION),
	                 suerte(SUERTE),
                         opciones(actividad,OPCION,NOMBRE,SUERTE), !.
                         			 
% a dormir
texto(MOMENTO,NOMBRE) :- nivel(final),
			 MOMENTO == final,
			 write("vaya dia sin parar!!!todo el dia haciendo!!!vaya vida mas agotadora!!!la vida de gato es muy dura... :P"), nl,
			 write(NOMBRE), write(" decide acabar el dia tal como le ha empezado, durmiendo, pero antes se comera unas croquetas de las que le gusta"), nl, nl,
			 separador, nl,
			 acciones(ACCIONES),
			 conclusion(ACCIONES, NOMBRE), nl, nl, !.
			
texto(MOMENTO,NOMBRE) :- MOMENTO == end,
		         write(NOMBRE), write(" ha realizado a lo largo del dia las acciones de: "), nl, nl,
			 acciones(ACCIONES),
			 accionesRealizadas(ACCIONES), nl.
 
% Define los predicados que se realizan dependiendo de las acciones a realizar
% Acciones que realizar para el desayuno. 
opciones(desayunar,despertar,NOMBRE,SUERTE) :- SUERTE > 2,
                                               nl, write(NOMBRE),
			                       write(" se acerca a su dueno, le arana un poco la nariz y le despierta"), nl,
			                       write("ha tenido suerte!! se ha despertado de buen humor y le ha dado su lata de comida favorita!!"), nl, nl,
			                       write(NOMBRE),
			                       write(" come mientras ronronea feliz!!!"), nl, 
					       write("empieza bien el dia!!! :)"), nl, nl,
					       assert(dueno(aranar)),
					       assert(accion(desayunar)),
				               agregar(desayunar), !.

opciones(desayunar,despertar,NOMBRE,SUERTE) :- SUERTE < 3,
                                               nl, write(NOMBRE),
			                       write(" se acerca a su dueno, le arana un poco la nariz... Pero este no despierta, cotinua roncando en su cama!!!"), nl,
			                       write("El pobre "),
			                       write(NOMBRE),
			                       write(" se queda hambriento y sin desayuno :( "), nl, nl,
                                               assert(dueno(aranar)), !.
					   
opciones(desayunar,buscar,NOMBRE,SUERTE)    :- SUERTE > 6,
                                               nl, write(NOMBRE),
			                       write(" se acerca al cubo de la basura, lo vuelca en el suelo y encuentra algo que le encanta"), nl,
			                       write("unas lonchas de jamon de york que su despistado dueno tiro a la basura por error!!!"), nl,
			                       write(NOMBRE),
			                       write(" come sus lonchas felizmente mientras ronronea!!!"), nl,
					       write("El suelo queda lleno de basura, pronto las hormigas llegaran..."), nl, nl,
					       assert(dueno(ensuciar)),
					       assert(accion(desayunar)),
					       agregar(buscar),
	       			               agregar(desayunar), !.

opciones(desayunar,buscar,NOMBRE,SUERTE)    :- SUERTE < 7,
                                               nl, write(NOMBRE),
			                       write(" vuelca el cubo de basura en el suelo y..."), nl,
					       write("solo encuentra latas de cerveza y bolsas de patatas fritas vacias!!"), nl,
					       write("vaya dueno que tiene..."), nl,
			                       write("El pobre "),
			                       write(NOMBRE),
			                       write(" se queda hambriento y sin desayuno :( "), nl,
					       write("El suelo queda lleno de basura... a ver si el dueno se alimenta mejor..."), nl, nl,
					       agregar(buscar),
					       assert(dueno(ensuciar)), !.

opciones(desayunar,cazar,NOMBRE,SUERTE)     :- SUERTE > 8,
                                               nl, write(NOMBRE),
			                       write(" recorre la casa entera en busca de algun raton..."), nl,
			                       write("oooh!!!ha encontrado uno..."), nl,
					       write("trata de cazarlo y lo consigue!!! lo lanza de un lado para otro jugueteando"), nl,
			                       write(NOMBRE),
			                       write(" termina de jugar con el y se lo come!!! mmmmh!!! que rico!!!!!!!!"), nl, nl,
					       assert(accion(desayunar)),
					       agregar(cazar),
	       			               agregar(desayunar), !.

opciones(desayunar,cazar,NOMBRE,SUERTE)     :- SUERTE < 9,
                                               nl, write(NOMBRE),
			                       write(" recorre la casa entera en busca de algun raton..."), nl,
			                       write("oooh!!!ha encontrado uno..."), nl,
					       write("trata de cazarlo y se escapa!!! se ha metido en el cajon de los calcetines del dueno!!!"), nl,
			                       write(NOMBRE), write(" se queda hambriento sin comer... :("), nl,
					       write("al menos el raton tendra un festin con los calcetines con olor a queso del dueno"), nl, nl,
					       agregar(cazar), !.
					       
% Si se no se introduce una opcion correcta, llama de nuevo al texto que indica la seleccion de la opcion
opciones(desayunar,_,NOMBRE,_)              :- nl, texto(desayunar,NOMBRE).    

% Acciones que realizar para la comida
opciones(comer,pediguenar,NOMBRE,SUERTE) :- SUERTE > 2,
                                            nl, write(NOMBRE),
					    write(" se acerca a su dueno y le mira con cara de bueno..."), nl,
					    write("miau!!!prrrr!!el dueno ha sacado una lata de sardinas y se las echa en su cuenco"), nl,
					    write(NOMBRE), write(" come feliz, le encantan las sardinas!!!"), nl, nl,
					    assert(accion(comer)),
					    agregar(pediguenar),
					    agregar(comer), !.				 
					    
opciones(comer,pediguenar,NOMBRE,SUERTE) :- SUERTE < 3,
                                            nl, write(NOMBRE), write(" busca a su dueno por toda la casa..."), nl,
					    write("parece que ha salido y se ha olvidado de dejar comida!!"), nl,
					    write(NOMBRE), write(" ha de buscar alguna manera de vengarse por tener un dueno tan irresponsable!!!"), nl,
					    write("Se sube a la estanteria y tira la coleccion de tazas del dueno al suelo..."), nl,
					    write("Asi aprendera a no olvidarse de un felino tan bonito!!!"), nl, nl,
					    assert(dueno(romper)), !.

opciones(comer,hurtar,NOMBRE,SUERTE)     :- SUERTE > 5,
					    nl, write("El dueno de "), write(NOMBRE), write(" esta preparando la comida"), nl,
					    write(NOMBRE), write(" busca la oportunidad de que su dueno se despiste y sisarle un trozo de pollo que esta cocinando..."), nl,
					    write("El dueno va a recoger unas especias a un armario... en ese momento de despiste "), write(NOMBRE), write(" salta y... hurta media pechuga de pollo..."), nl,
					    write(NOMBRE), write(" corre a su comedero y disfruta de la pechuga afanada!!!"), nl, nl,
					    assert(accion(comer)),
					    agregar(hurtar),
					    agregar(comer), !.
 
opciones(comer,hurtar,NOMBRE,SUERTE)     :- SUERTE < 6,
                                            nl, write("El dueno de "), write(NOMBRE), write(" esta preparando la comida"), nl,
					    write(NOMBRE), write(" busca la oportunidad de que su dueno se despiste y sisarle un trozo de pollo que esta cocinando..."), nl,
					    write("El dueno va a recoger unas especias a un armario... en ese momento de despiste "), write(NOMBRE), write(" salta y ...oh oh!!"), nl,
					    write("Su dueno le ha pillado!!! Ademas de reganarle, castiga al pobre "), write(NOMBRE), write(" sin comer..."), nl,
					    write(NOMBRE), write(" se va a su rincon con la cabeza agachada y triste por no haber podido afanar la pechuga :("), nl, nl,
					    agregar(hurtar),
					    assert(dueno(reganar)), !.

opciones(comer,escapar,NOMBRE,SUERTE)    :- SUERTE > 8,
                                            nl, write("Por la ventana viene un olor genial...mmmh, que sera???"), nl,
					    write(NOMBRE), write(" encuentra un hueco por la ventana por donde salir y se acerca hasta casa del vecino..."), nl,
					    write("En su ventana hay un delicioso pastel de carne enfriandose y no hay moros en la costa..."), nl,
					    write(NOMBRE), write(" salta a por el y se lo empieza a comer!!!"), nl,
					    write("Que delicioso esta!!!Ya podria su dueno aprender a cocinar tan bien!!!"), nl, nl,
					    assert(accion(comer)),
					    agregar(escapar),
					    agregar(comer), !.
					    
opciones(comer,escapar,NOMBRE,SUERTE)    :- SUERTE < 9,
                                            nl, write("Por la ventana viene un olor genial...mmmh, que sera???"), nl,
					    write(NOMBRE), write(" encuentra un hueco por la ventana por donde salir y se acerca hasta casa del vecino..."), nl,
					    write("En su ventana hay un delicioso pastel de carne enfriandose"), nl,
					    write(NOMBRE), write(" se acerca sigilosamente hacia la ventana salta y..."), nl,
					    write("El vecino justo a cerrado la ventana en los morros de "), write(NOMBRE), write("!!!"), nl,
					    write("Que mala suerte ha tenido, se ha quedado con la miel en los labios... :("), nl, nl, 
					    agregar(escapar), !.
					    
% Si se no se introduce una opcion correcta, llama de nuevo al texto que indica la seleccion de la opcion
opciones(comer,_,NOMBRE,_)               :- nl, texto(comer,NOMBRE).

% distintas opciones que realizar para la actividad de la tarde			
opciones(actividad,aluminio,NOMBRE,SUERTE) :- SUERTE > 2,
                                              nl, write(NOMBRE), write(" decide jugar con alguna de las bolitas de papel albal que hay por casa"), nl,
					      write("Encuentra una y empieza a darle patadas y a corretear como loco por toda la casa, que bien se lo esta pasando!!! :)"), nl,
					      write(NOMBRE), write(" acaba cansado, ha sido una actividad agotadora!!!"), nl, nl,
					      assert(accion(jugar)),
					      assert(accion(correr)),
					      agregar(jugar),
					      agregar(correr), !.
					      
opciones(actividad,aluminio,NOMBRE,SUERTE) :- SUERTE < 3,
                                              nl, write(NOMBRE), write(" decide jugar con alguna de las bolitas de papel albal que hay por casa"), nl,
					      write("No encuentra ninguna!!! que raro, donde estaran? si siempre hay por todos los lados!!"), nl,
					      write("vaya sorpresa!!todo esta limpio!!menudo milagro, parece que su dueno ha limpiado la casa!!"), nl,
					      write("Estara enfermo el dueno de "), write(NOMBRE), write("? miki se queda atonito por ver la casa tan limpia"), nl,
					      write("El pobre "), write(NOMBRE), write(" se queda aburrido mirando por la ventana a ver si ve algo interesante..."), nl, nl,
					      assert(accion(aburrido)),
					      agregar(aburrido), !.

opciones(actividad,manicura,NOMBRE,SUERTE) :- SUERTE > 8,
                                              nl, write(NOMBRE), write(" necesita estar guapo por si algun dia de estos conoce a alguna gatita"), nl,
					      write("La manera que tiene el de ir al salon de belleza es afilando sus unas con los muebles de la casa"), nl,
					      write("Corre por toda la casa aranando todos los muebles para que sus unas sean lo mas bonitas posible, le encanta sobre todo el sofa..."), nl,
					      write(NOMBRE), write(" acaba cansado, ha sido una actividad agotadora!!!"), nl, nl,
					      assert(accion(correr)),
					      agregar(jugar),
					      agregar(correr), !.
					      
opciones(actividad,manicura,NOMBRE,SUERTE) :- SUERTE < 9,
                                              nl, write(NOMBRE), write(" necesita estar guapo por si algun dia de estos conoce a alguna gatita"), nl,
					      write("La manera que tiene el de ir al salon de belleza es afilando sus unas con los muebles de la casa"), nl,
					      write("Corre por toda la casa aranando todos los muebles para que sus unas sean lo mas bonitas posible, le encanta sobre todo el sofa..."), nl,
					      write("oh oh!!!su dueno le ha pillado!! menuda bronca le esta echando!!pobre "), write(NOMBRE), write(" el solo queria estar guapo"), nl,
					      write(NOMBRE), write(" acaba cansado, ha sido una actividad agotadora!!!"), nl, nl,
					      assert(accion(correr)),
					      assert(dueno(destrozar)), !.
					      
opciones(actividad,trepar,NOMBRE,SUERTE)   :- SUERTE > 5,
                                              nl, write(NOMBRE), write(" se cree que es un montanistaista y decide trepar la cortina que la suegra de su dueno le cosio..."), nl,
					      write("La trepa hasta llegar al techo y desde alli puede tener controlado todo lo que pasa en la casa"), nl,
					      write("Se cree el rey del mundo ahi arriba, no hay nadie que le pueda decir nada!!!"), nl,
					      write(NOMBRE), write(" acaba cansado, ha sido una actividad agotadora!!!"), nl, nl,
					      assert(accion(trepar)),
					      agregar(trepar), !.

opciones(actividad,trepar,NOMBRE,SUERTE)   :- SUERTE < 6,
                                              nl, write(NOMBRE), write(" se cree que es un montanista y decide trepar la cortina que la suegra de su dueno le cosio..."), nl,
					      write("Empieza a treparla y cuando va por mitad de camino la cosa pinta mal..."), nl,
					      write("Suena un fuerte sonido y la cortina se rompe!!!"), nl,
					      write("El pobre "), write(NOMBRE), write(" se cae desde lo alto y se da un buen coscorron!!!"), nl,
					      write("por suerte, parece que esta bien."), nl,
					      write("sale corriendo por toda la casa del susto y acaba escondido en una caja de carton"), nl,
					      write(NOMBRE), write(" acaba cansado, ha sido una actividad agotadora!!!"), nl, nl,
					      assert(accion(trepar)),
					      assert(accion(correr)),
					      agregar(correr),
					      agregar(trepar), !.

opciones(actividad,_,NOMBRE,_)             :- nl, texto(actividad,NOMBRE).

% Devuelve el estado de animo con el que el gato ha acabado el dia
conclusion(_,NOMBRE) :-        duenoEnfadado,
			       write("El dueno de "), write(NOMBRE),
			       write(" ha acabado el dia muy enfadado con el, le ha echado a dormir fuera a la calle!!!!!!!!! :("), nl,
                               write("Pobre "), write(NOMBRE), write(" esta noche la pasara fuera... Asi tendra tiempo para hurgar en las basuras y quizas encontrar algun manjar!!"), !.

conclusion(ACCIONES,NOMBRE) :- contiene(desayunar,ACCIONES),
			       contiene(comer,ACCIONES),
			       contiene(jugar,ACCIONES), 
			       contiene(correr,ACCIONES),
			       agregar(ronronear),
			       write(NOMBRE),
			       write(" ha acabado el dia muy feliz y con el estomago lleno, se acuesta a los pies de su dueno ronroneando!!!"), nl,
                               write("esta noche sonara con cosas bonitas!! :)"), !.
			       
conclusion(ACCIONES,NOMBRE) :- contiene(comer,ACCIONES),
			       contiene(jugar,ACCIONES), 
			       contiene(correr,ACCIONES),
			       agregar(ronronear),
			       write(NOMBRE),
			       write(" ha acabado el dia muy feliz pero con un poco de hambre, no ha desayunado, se acuesta a los pies de su dueno ronroneando!!!"), nl,
                               write("esta noche sonara con cosas bonitas!! :)"), !.
			       
conclusion(ACCIONES,NOMBRE) :- contiene(desayunar,ACCIONES),
			       contiene(jugar,ACCIONES), 
			       contiene(correr,ACCIONES),
			       agregar(ronronear),
			       write(NOMBRE),
			       write(" ha acabado el dia muy feliz pero con un poco de hambre, no ha comido, se acuesta a los pies de su dueno ronroneando!!!"), nl,
                               write("esta noche sonara con cosas bonitas!! :)"), !.

conclusion(ACCIONES,NOMBRE) :- contiene(jugar,ACCIONES), 
			       contiene(correr,ACCIONES),
			       write(NOMBRE),
			       write(" ha acabado el dia muy feliz pero con un poco de hambre, no ha comido en todo el dia, se acuesta con su estomago enfadado!!!"), nl,
                               write("esta noche sonara con comida!!"), !.
			      		       
conclusion(ACCIONES,NOMBRE) :- contiene(desayunar,ACCIONES),
			       contiene(comer,ACCIONES),
			       write(NOMBRE),
			       write(" lo unico que ha hecho durante todo el dia ha sido comer, se acuesta un poco mas gordo!!"), nl,
                               write("esta noche sonara con mas comida!! :)"), !.

conclusion(_,NOMBRE)        :- write(NOMBRE),
			       write(" ha pasado un dia un poco malo, ni comer ni ninguna actividad provechosa... :( pobrecito!!"), nl,
                               write("Para olvidar el dia desastroso ha decidido irse pronto a la cama para olvidar, a ver si manana es un dia mejor!!!"), !.	
			       

% Predicado principal. Ejecuta secuencialmete con los predicados definidos previamnente
miau :- inicio_juego, nl,
        separador,
        gato(NOMBRE),
	texto(despertar,NOMBRE),
	texto(desayunar,NOMBRE),
	separador, nl,
	retract(nivel(1)),
	assert(nivel(2)),
	texto(manana,NOMBRE),
	separador, nl,
	pausar, nl,
	separador, nl,
	assert(nivel(3)),
	texto(comida,NOMBRE),
	texto(comer,NOMBRE),
	separador, nl,
	retract(nivel(3)),
	assert(nivel(4)),
	texto(siesta,NOMBRE),
	separador, nl,
	pausar, nl,
	separador, nl,
	retract(nivel(4)),
	assert(nivel(5)),
	texto(tarde,NOMBRE),
	texto(actividad,NOMBRE),
	separador, nl,
	retract(nivel(5)),
	assert(nivel(final)),
	pausar, nl,
	separador, nl,
	texto(final,NOMBRE),
	separador, nl,
	texto(end,NOMBRE),
	separador, nl,
	retract(nivel(final)),
	%Se reinicia la BC para poder empezar otra vez de nuevo
	retractall(acciones(_)),
	retractall(accion(_)),
	retract(gato(_)),
	retractall(dueno(_)),
	assert(acciones([despertar])),
	assert(dueno(iniciar)),
	assert(accion(despertar)).