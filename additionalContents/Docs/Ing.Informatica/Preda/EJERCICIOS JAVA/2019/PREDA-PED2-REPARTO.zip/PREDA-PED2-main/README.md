# PREDA-PED2

Repartiment equitatiu d'actius.
