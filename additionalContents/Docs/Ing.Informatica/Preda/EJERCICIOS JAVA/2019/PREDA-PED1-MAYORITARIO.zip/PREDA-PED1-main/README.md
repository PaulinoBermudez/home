# PREDA-PED1
Calcular l'element majoritari d'un vector.
