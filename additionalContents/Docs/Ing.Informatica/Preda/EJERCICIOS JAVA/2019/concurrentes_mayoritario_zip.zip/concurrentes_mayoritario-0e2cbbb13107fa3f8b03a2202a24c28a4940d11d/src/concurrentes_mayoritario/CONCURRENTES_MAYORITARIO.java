
package concurrentes_mayoritario;

import Mayoritario.Clasico.Mayor;
import java.util.Random;

/**
 * <b>Clase principal que ejecuta la aplicación.</b>
 * @author José Ángel Pastrana Padilla
 */
public class CONCURRENTES_MAYORITARIO {
    /**
     * <b>Desordena los elementos en un vector.</b>
     * @param vector Vector de entrada.
     */
    public static void shuffle(int[] vector) {
        for (int i=0, s=vector.length - 1; i<s; ++i) {
            int newPos = i + (new Random().nextInt(vector.length - i));
            int temp = vector[newPos];
            vector[newPos] = vector[i];
            vector[i] = temp;
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Declaración de variables.
        int n = 10000; // Tamaño del conjunto de datos.
        int[] vector = new int[n]; // Vector como conjunto.
        int elemento = 14235; // Elemento a introducir como elemento mayoritario.
        
        // Entropía. Decide en la ejecucion, si el problema será generado con elemento mayoritario o no.
        // Pon a 0 para que no exista elemento mayoritario.
        // Pon a 1 para que sí exista elemento mayoritario.
        int habraMayoritario = 1;//new Random().nextInt(2);
        
        // Generación del problema.
        for (int i=0, s=(n/2)+habraMayoritario; i<s; ++i) {
            vector[i] = elemento;
        }
        for (int i=(n/2)+habraMayoritario; i<vector.length; ++i) {
            vector[i] = new Random().nextInt(elemento); // El rango de valores generados aleatoriamente comprende el rango [0,elemento), donde elemento no es incluído.
        }
        shuffle(vector); // Desordena los elementos.
        
        // Ejecuta algoritmos.
            // Algoritmo clásico.
            Mayor rClasico = Mayoritario.Clasico.run(vector);
            // DyV
            // DyV Fork-Join
        
        // Mostrar resultados por pantalla.
            // Vector generado.
            System.out.println("Elementos del vector generado:");
            for (int i=0; i<n; ++i) System.out.println(vector[i]);
            System.out.print('\n');
        
            // Conclusiones.
            System.out.println("Conclusiones:");
                // Clásico
                System.out.print("ALGORITMO CLÁSICO: ");
                if (rClasico!=null) {
                    System.out.println("Existe elemento mayoritario, es " + rClasico.elemento + " y se repite " + rClasico.ocurrencias + " veces."); 
                } else {
                    System.out.println("No existe elemento mayoritario.");
                }
                // DyV
                // DyV Fork-Join
    }
    
}
