
package Mayoritario;

import java.util.HashSet;

/**
 * <b>Algoritmo clásico para encontrar el elemento mayoritario en un conjunto de datos.</b>
 * @author José Ángel Pastrana Padilla
 */
public class Clasico {
    
    /**
     * <b>Pareja de elementos, mayoritario y veces de ocurrencia en el conjunto de datos.</b>
     */
    public static class Mayor {
        /**
         * Elemento mayoritario.
         */
        public final Integer elemento;
        
        /**
         * Ocurrencias del elemento mayoritario en el conjunto de datos.
         */
        public final int ocurrencias;
        
        /**
         * <b>Constructor de la clase con los argumentos necesarios.
         * @param _elemento Elemento mayoritario.
         * @param _ocurrencias Ocurrencias del elemento mayoritario.
         */
        Mayor (Integer _elemento, int _ocurrencias) {
            elemento    = _elemento;
            ocurrencias = _ocurrencias;
        }
    }
    
    /**
     * <b>Lógica del algoritmo clásico para encontrar el elemento mayoritario en un conjunto de datos.</b>
     * @param vector Vector de entrada.
     * @return Si existe el elemento mayoritario (ocurrencias > n/2), tipo Mayor. Si no existe, null.
     */
    public static Mayor run(int[] vector) {
        Integer elementoMasFrecuente = null;
        int ocurrenciasMasFrecuente = 0;
        HashSet<Integer> repetidos = new HashSet<>();
        
        for (int i=0, s=(vector.length+1)/2; i<s; ++i) {
            if (!repetidos.contains(vector[i])) {
                repetidos.add(vector[i]);
                int oc = 1; // Cantidad de ocurrencias encontradas en el i-ésimo elemento.
                for (int j=i+1; j<vector.length; ++j) {
                    if (vector[i] == vector[j]) ++oc;
                }
                if (ocurrenciasMasFrecuente < oc) { // Si el i-ésimo elemento tiene más ocurrencias que el actual, se sustituye.
                    elementoMasFrecuente = vector[i];
                    ocurrenciasMasFrecuente = oc;
                }
            }
        }
        if (ocurrenciasMasFrecuente > vector.length/2) { // El elemento más frecuente, si es mayor de n/2, también es elemento mayoritario.
            return new Mayor(elementoMasFrecuente,ocurrenciasMasFrecuente);
        } else {
            return null;
        }
    }
}
