# ScheduleGenerator
Generates schedules for sports teams with and without divisions

Supported: 
16 teams with 4 divisions
12 teams with 3, 4 divisions
10 teams with 2, 5 divisions
8 teams with 4, 2 divisions

Would like to: 
-add arc consistency for speed.
-explore local search as a possibility
