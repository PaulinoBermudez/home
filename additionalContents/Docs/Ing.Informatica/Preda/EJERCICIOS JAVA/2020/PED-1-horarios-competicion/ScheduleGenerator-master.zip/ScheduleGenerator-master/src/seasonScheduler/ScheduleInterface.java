package seasonScheduler;

public interface ScheduleInterface {
	Week[] constructSchedule();
	void printByTeam();
	void printByWeek();
}
