package app;

import gui.Gui;

/**
 * Clase principal
 * @author Inazio
 *
 */
public class App {

	public static void main(String[] args) {
		
		@SuppressWarnings("unused")
		Gui gui = new Gui();
		
	}
}
